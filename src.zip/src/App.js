import React, { useState, useEffect } from 'react';
import './App.css';
import axios from 'axios';
import {
	getBelmontCitydetails,
	getSmyrnaCitydetails
} from './app-store/actions';
import {useSelector, useDispatch} from 'react-redux';

export default function App() {

const belmontCities = useSelector(state => state.citiesReducer.belmontCitydetails);
const smyrnaCities = useSelector(state => state.citiesReducer.smyrnaCitydetails);
const dispatch = useDispatch();

  useEffect(() => {
    const getBelmontCityDetails = async () => {
      await axios
        .get('https://api.zippopotam.us/us/MA/Belmont')
        .then(response => {
          console.log(response.data);
          dispatch(getBelmontCitydetails(response.data));
        })
        .catch(error => {
          console.log(error);
        });
    };
    getBelmontCityDetails();
    const getSmyrnaCityDetails = async () => {
      await axios
        .get('https://api.zippopotam.us/us/GA/Smyrna')
        .then(response => {        	
          console.log(response.data);
          dispatch(getSmyrnaCitydetails(response.data));          
        })
        .catch(error => {
          console.log(error);
        });
    };
    getSmyrnaCityDetails();
  }, []);
  console.log("belmontCities", belmontCities)
  console.log("smyrnaCities", smyrnaCities)

  return (
    <div>
      <h1>Cities</h1>
      {belmontCities.places && belmontCities.places.map((item, index) => {
      	return (<div key={index}><div>
      	Place Name: {item["place name"]}
      	</div>
      	<div>
      	Post Code: {item["post code"]}
      	</div>
      	<div>
      	Lat: {item["latitiude"]}
      	</div>
      	<div>
      	Lat: {item["longitude"]}
      	</div></div>)
      })}
    </div>
  );
}
