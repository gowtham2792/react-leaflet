import { combineReducers } from 'redux';
import citiesReducer from './app-store/reducer';

const rootReducers = combineReducers({
  citiesReducer
});

export default rootReducers;
